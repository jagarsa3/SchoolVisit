DROP TABLE #__visit;
DROP TABLE #__servidor;
