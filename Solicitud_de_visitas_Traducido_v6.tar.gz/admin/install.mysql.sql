CREATE TABLE IF NOT EXISTS `#__visit` (
`id` int(11) NOT NULL auto_increment,
`nameCole` varchar(255) NOT NULL,
`dir` varchar(255) NOT NULL,
`city` varchar(255) NOT NULL,
`nameProfe` varchar(255) NOT NULL,
`telf` int(20) NOT NULL,
`movil` int(11) NOT NULL,
`email` varchar(255) NOT NULL,
`numInf` int(11) NOT NULL,
`numPrim` int(11) NOT NULL,
`numAcomp` int(11) NOT NULL,
`parque` varchar(255) NOT NULL,
`fecha` date NOT NULL,
`observaciones` varchar(255) NOT NULL,
`num_visitas` int(11) NOT NULL,
PRIMARY KEY (`id`)
);
CREATE TABLE IF NOT EXISTS `#__servidor` (
`id` int(11) NOT NULL auto_increment,
`nombreServidor` varchar(255) NOT NULL,
`usuario` varchar(255) NOT NULL,
`password` varchar(255) NOT NULL,
`baseDatos` varchar(255) NOT NULL,
`activado` int(11) NOT NULL,
`baseDatosTabla` varchar(255) NOT NULL,
`descripcion` varchar(255) NOT NULL,
PRIMARY KEY (`id`)
);
INSERT INTO `#__servidor` (`id`, `nombreServidor`, `usuario`, `password`, `baseDatos`, `activado`,`baseDatosTabla`,`descripcion`) VALUES ('1', 'venus', 'usuario_apps', 'adrian', 'HOSTDB1', '1','colegios','Guardar Datos Solicitud');
INSERT INTO `#__servidor` (`id`, `nombreServidor`, `usuario`, `password`, `baseDatos`, `activado`,`baseDatosTabla`,`descripcion`) VALUES ('2', 'venus', 'usuario_apps', 'adrian', 'HOSTDB2', '1','maestros','Listar Parques de Bomberos');
INSERT INTO `#__servidor` (`id`, `nombreServidor`, `usuario`, `password`, `baseDatos`, `activado`,`baseDatosTabla`,`descripcion`) VALUES ('3', 'venus', 'usuario_apps', 'adrian', 'HOSTDB3', '1','secretaria','Listar Poblaciones');
INSERT INTO `#__servidor` (`id`, `nombreServidor`, `usuario`, `password`, `baseDatos`, `activado`,`baseDatosTabla`,`descripcion`) VALUES ('4', 'jupiter', 'usuario_apps', 'adrian', 'HOSTDB1', '0','colegios','Guardar Datos Solicitud');
INSERT INTO `#__servidor` (`id`, `nombreServidor`, `usuario`, `password`, `baseDatos`, `activado`,`baseDatosTabla`,`descripcion`) VALUES ('5', 'jupiter', 'usuario_apps', 'adrian', 'HOSTDB2', '0','maestros','Listar Parques de Bomberos');
INSERT INTO `#__servidor` (`id`, `nombreServidor`, `usuario`, `password`, `baseDatos`, `activado`,`baseDatosTabla`,`descripcion`) VALUES ('6', 'jupiter', 'usuario_apps', 'adrian', 'HOSTDB3', '0','secretaria','Listar Poblaciones');
