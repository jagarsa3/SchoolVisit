<?php


/*
-------------------------------------------------------------------------------------------
FICHERO:		admin.visit.html.php
-------------------------------------------------------------------------------------------
			showVisit( $servidores, $option, $id)

FUNCION(ES):	Muestra el registro de un servidor
LLAMANTE(S):	function showVisit($option ) de admin.visit.php
PARAMETROS:	$option -> com_visit, $servidores, $id -> datos servidor

			showVisits( $option, &$rows)

FUNCION(ES):	Muestra todos los servidores
LLAMANTE(S):	function showVisits ( $option ) de admin.visit.php
PARAMETROS:	$option -> com_visit, $rows-> servidores

-------------------------------------------------------------------------------------------
CREACIÓN
-------------------------------------------------------------------------------------------
AUTOR:			Javier García San Juan
FECHA:			07/10/2010
-------------------------------------------------------------------------------------------
MODIFICACIONES
-------------------------------------------------------------------------------------------
AUTOR:		Javier García San Juan
FECHA:		11/10/2010
CAMBIOS:	Añadida paginación en el back-end

-------------------------------------------------------------------------------------------
AUTOR:          Javier García San Juan
FECHA:          13/10/2010
CAMBIOS:        Fechas mas vistosas con JHTML::Date(fecha)

-------------------------------------------------------------------------------------------
AUTOR:
FECHA:
CAMBIOS:

-------------------------------------------------------------------------------------------

*/

require_once("DB.php");

defined( '_JEXEC' ) or die ( 'Restricted access' ) ;
class HTML_visit
{
	function showVisit( $servidores, $option, $id)
	{

                // CARGAMOS EL SERVIDOR DESDE JOOMLA ACTIVO
                $db =& JFactory::getDBO();
                
                
                $query = "SELECT * FROM #__servidor WHERE id='".$id."'";
                $db->setQuery( $query);
                
                $rowserver = $db->loadRow();
		$editor =& JFactory::getEditor();




                $city[0] = array('value' => 'Guardar Datos Solicitud','text'=>'Guardar Datos Solicitud');
                $city[1] = array('value' => 'Listar Parques de Bomberos','text'=>'Listar Parques de Bomberos');
                $city[2] = array('value' => 'Listar Poblaciones','text'=>'Listar Poblaciones');



                $lists['descripcion'] = JHTML::_('select.genericList',
			$city,'descripcion','class="inputbox" '.' ', 'value','text' );

		?>
		<p class="contentheading"><strong><h2><u><?php echo $rowserver[1]; ?></u></h2></strong></p>
		<p class="createdate"><?php $fecha_actual = date(d."-".m."-".Y);?></p>


                <!-- FORMULARIO PARA EL SERVIDOR-->


                <form action="index.php" method="post"
				name="adminForm" id="adminForm">
			<fieldset class="adminform">
				<legend><h3><?php echo JText::_( 'Regusuario' )?></h3></legend>
				<table class="admintable">
				<tr>
					<td width="250" align="right" class="key">
						<?php echo JText::_( 'Usuario'); ?>:(*)
					</td>
					<td>
						<input class="text_area" type="text" name="usuario"
							id="usuario" size="50" maxlength="250"
							value="<?php if($rowserver['2']=='')
                                                        {
                                                            echo "usuario_apps";
                                                        }
                                                        else echo $rowserver['2'];?>" />
                                                
                                                
						
					</td>
				</tr>

				<tr>
					<td width="100" align="right" class="key">
						<?php echo JText::_( 'Password'); ?>:(*)
					</td>
					<td>
						<input class="text_area" type="text" name="password"
							id="password" size="50" maxlength="250"
							value="<?php echo $rowserver['3'];?>" />
						
					</td>
				</tr>
				<tr>
					<td width="100" align="right" class="key">
						<?php echo JText::_( 'Constante'); ?>:(*)
					</td>
					<td>
                                                <input class="text_area" type="text" name="baseDatos"
							id="baseDatos" size="50" maxlength="250"
							value="<?php echo $rowserver['4'];?>" readonly />
						
						
					</td>
				</tr>
                                <tr>
					<td width="100" align="right" class="key">
						<?php echo JText::_( 'Basedatos'); ?>:(*)
					</td>
					<td>
						<input class="text_area" type="text" name="baseDatosTabla"
							id="baseDatosTabla" size="50" maxlength="250"
							value="<?php echo $rowserver['6'];?>" />

					</td>
				</tr>
                                <tr>
					<td width="100" align="right" class="key">
						<?php echo JText::_( 'Funcion'); ?>:(*)
					</td>
					<td>
                                                <input class="text_area" type="text" name="descripcion"
							id="descripcion" size="50" maxlength="250"
							value="<?php echo $rowserver['7'];?>" readonly />
						

					</td>
				</tr>
                                </table>
			</fieldset>
			<input type="hidden" name="nombreServidor" id="nombreServidor" value="<?php  echo  $rowserver[1]; ?>" />
			<input type="hidden" name="option" value="<?php echo $option; ?>" />
			<input type="hidden" name="task" value="save" />
			<input type="submit" class="button" id="button" value="<?php echo JText::_( 'Enviar'); ?>" />
			<input type="reset" class="button" id="clean" value="<?php echo JText::_( 'Limpiar'); ?>" />
		</form>
                <br/>

                
		<?php $link = JRoute::_('index.php?option=' . $option); ?>
		<a href="<?php echo $link; ?>">&lt;<?php echo JText::_( 'Listado'); ?></a>

		<?php
	}

        function AddServer($option, $id)

        {
                $editor =& JFactory::getEditor();




                $city[0] = array('value' => 'Guardar Datos Solicitud','text'=>'Guardar Datos Solicitud');
                $city[1] = array('value' => 'Listar Parques de Bomberos','text'=>'Listar Parques de Bomberos');
                $city[2] = array('value' => 'Listar Poblaciones','text'=>'Listar Poblaciones');



                $lists['descripcion'] = JHTML::_('select.genericList',
			$city,'descripcion','class="inputbox" '.' ', 'value','text' );
                
                

		?>
                <script type="text/javascript">
                function guardar_datos(f){
                    //if(comprobar_datos(f)){
                            f.submit();
                    //}
                }
                </script>
		<p class="createdate"><?php $fecha_actual = date(d."-".m."-".Y);?></p>


                <!-- FORMULARIO PARA EL SERVIDOR-->


                <form action="" method="post"
				name="adminForm" id="adminForm">
			<fieldset class="adminform">
				<legend><h3><?php echo JText::_( 'Regusuario' )?></h3></legend>
				<table class="admintable">
                                <tr>
					<td width="100" align="right" class="key">
						<?php echo JText::_( 'Nombre del Servidor'); ?>:(*)
					</td>
					<td>
						<input class="text_area" type="text" name="nombreServidor"
							id="nombreServidor" size="50" maxlength="250"
							value="" />

					</td>
				</tr>
				<tr>
					<td width="250" align="right" class="key">
						<?php echo JText::_( 'Usuario'); ?>:(*)
					</td>
					<td>
						<input class="text_area" type="text" name="usuario"
							id="usuario" size="50" maxlength="250"
							value="<?php 
                                                        
                                                            echo "usuario_apps";?>" />



					</td>
				</tr>

				<tr>
					<td width="100" align="right" class="key">
						<?php echo JText::_( 'Password'); ?>:(*)
					</td>
					<td>
						<input class="text_area" type="text" name="password"
							id="password" size="50" maxlength="250"
							value="" />

					</td>
				</tr>

                                <tr>
					<td width="100" align="right" class="key">
						<?php echo JText::_( 'Basedatos'); ?>:(*)
					</td>
					<td>
						<input class="text_area" type="text" name="baseDatosTabla"
							id="baseDatosTabla" size="50" maxlength="250"
							value="" />

					</td>
				</tr>
                                <tr>
					<td width="100" align="right" class="key">
						<?php echo JText::_( 'Funcion'); ?>:(*)
					</td>
					<td>
						<?php echo $lists['descripcion'];?>

					</td>
				</tr>
                                </table>
			</fieldset>
			
			<input type="hidden" name="option" value="<?php echo $option; ?>" />
			<input type="hidden" name="task" value="save_new" />
			<input type="button" class="button" id="guardar "onClick="guardar_datos(this.form)" value="<?php echo JText::_( 'Enviar'); ?>">
			<input type="reset" class="button" id="clean" value="<?php echo JText::_( 'Limpiar'); ?>" />
		</form>
                <br/>


		<?php $link = JRoute::_('index.php?option=' . $option); ?>
		<a href="<?php echo $link; ?>">&lt;<?php echo JText::_( 'Listado'); ?></a>

		<?php
        
 
        }



	function showVisits( $option, &$rows, &$pageNav)
	{
		?>

		<form action="" method="post" name="adminForm">
		<table class="adminlist">
			<thead>
				<tr>
					<th width="2%">
						#
					</th>
					<th width="35%" class="title" colspan="2"><?php echo JText::_( 'Nombre'); ?></th>
                                        <th width="35%" class="title" ><?php echo JText::_( 'Tabla'); ?></th>
                                        <th width="35%"><?php echo JText::_( 'Activo'); ?></th>

				</tr>
			</thead>
			
			<?php
			jimport('joomla.filter.output');
			$k = 0;

                        // CARGAMOS EL SERVIDOR DESDE JOOMLA ACTIVO
                        $db =& JFactory::getDBO();
                        $user = & JFactory :: getUser();
                        $query = "SELECT * FROM #__servidor WHERE activado='1'";
                        $db->setQuery( $query);
                        $rowserver = $db->loadRow();

                        $dbconsulta =& JFactory::getDBO();
                        $consulta = "SELECT * FROM #__servidor";
                        $dbconsulta->setQuery( $consulta);
                        $rowconsulta = $dbconsulta->loadObjectList();
                        $i=1;
			foreach($rowconsulta as $rowdb)
                        {
				//$rowdb= &$rows[$i];
				$checked = JHTML::_('grid.id',$i,$rowdb->id);
				$published = JHTML::_('grid.published',$rowdb,$rowdb->id);
				$link = JFilterOutput::ampReplace('index.php?option='.$option.'&task=edit&cid[]='.$rowdb->id);
				?>
				<tr class="<?php echo "row$k"; ?> " >
				<td>
					<?php echo $i; ?>
				</td>
                                <td width="5%">
					<?php


?>
							&nbsp;
							<?php


?>
							<input type="radio" id="cb<?php echo $rowdb->id;?>" name="cid[]" value="<?php echo $rowdb->id;?>" onclick="isChecked(this.checked);" />

							<?php 


?>

                                </td>
				<td align="center" width="50%">
					<a href="<?php echo $link; ?>">
					<?php echo $rowdb->nombreServidor; ?></a>
				</td>
                                <td align="center" width="50%">
					<a href="<?php echo $link; ?>">
					<?php echo $rowdb->baseDatosTabla; ?></a>
				</td>
                                
				<td align="center">
					<?php
                                            if($rowdb->activado == 1)
                                            {
                                                ?><img src="templates/khepri/images/menu/icon-16-default.png" alt="<?php echo JText::_( 'Default' ); ?>" />
                                                <?php
                                             }
                                        ?>
				</td>
                                
				<?php
				$k = 1-$k;
                                $i = $i+1;
			}
			?>
                        <tfoot>
                            <td colspan="7"><?php echo $pageNav->getListFooter(); ?></td>
                        </tfoot>
			</table>
                        
			<input type="hidden" name="option" value="<?php echo $option;?>" />
			<input type="hidden" name="task" value=""/>
			<input type="hidden" name="boxchecked" value="0"/>
		</form>
		<?php
	
			

    }

}


	?>

