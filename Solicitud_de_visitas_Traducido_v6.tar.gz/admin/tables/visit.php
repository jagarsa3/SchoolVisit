<?php

/*
-------------------------------------------------------------------------------------------
FICHERO:		visit.php
-------------------------------------------------------------------------------------------
			class TableVisit extends JTable		

FUNCION(ES):	Inicialización visit
LLAMANTE(S):
PARAMETROS:	


-------------------------------------------------------------------------------------------
CREACIÓN
-------------------------------------------------------------------------------------------
AUTOR:			Javier García San Juan
FECHA:			07/10/2010
-------------------------------------------------------------------------------------------
MODIFICACIONES
-------------------------------------------------------------------------------------------
AUTOR:		
FECHA:			
CAMBIOS:		

-------------------------------------------------------------------------------------------

*/



defined ( '_JEXEC' ) or die ( 'Restricted access' );
class TableVisit extends JTable
{
	var $id = null;
	var $nameCole = null;
	var $dir = null;
	var $city = null;
	var $nameProfe = null;
	var $telf = null;
	var $movil = null;
	var $email = null;
	var $numInf = null;
	var $numPrim = null;
	var $numAcomp = null;
	var $parque = null;
	var $fecha = null;
	var $observaciones = null;
	function __construct(&$db)
	{
		parent::__construct ( '#__visit', 'id', $db);
	}
}
?>
