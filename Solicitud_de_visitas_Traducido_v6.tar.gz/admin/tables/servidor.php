<?php

/*
-------------------------------------------------------------------------------------------
FICHERO:		visit.php
-------------------------------------------------------------------------------------------
			class TableVisit extends JTable		

FUNCION(ES):	Inicialización Servidor
LLAMANTE(S):
PARAMETROS:	


-------------------------------------------------------------------------------------------
CREACIÓN
-------------------------------------------------------------------------------------------
AUTOR:			Javier García San Juan
FECHA:			21/10/2010
-------------------------------------------------------------------------------------------
MODIFICACIONES
-------------------------------------------------------------------------------------------
AUTOR:		
FECHA:			
CAMBIOS:		

-------------------------------------------------------------------------------------------

*/



defined ( '_JEXEC' ) or die ( 'Restricted access' );
class TableServidor extends JTable
{
	var $id = null;
	var $nombreServidor = null;
	var $usuario = null;
	var $password = null;
	var $baseDatos = null;
	var $activado = null;
	var $baseDatosTabla = null;
	var $descripcion = null;

	function __construct(&$db)
	{
		parent::__construct ( '#__servidor', 'id', $db);
	}
}
?>
