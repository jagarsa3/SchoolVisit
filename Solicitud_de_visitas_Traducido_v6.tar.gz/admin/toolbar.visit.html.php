<?php

/*
-------------------------------------------------------------------------------------------
FICHERO:		toolbar.visit.html.php
-------------------------------------------------------------------------------------------
			TOOLBAR	

FUNCION(ES):	Carga los botones para el componente visit
LLAMANTE(S):
PARAMETROS:	


-------------------------------------------------------------------------------------------
CREACIÓN
-------------------------------------------------------------------------------------------
AUTOR:			Javier García San Juan
FECHA:			07/10/2010
-------------------------------------------------------------------------------------------
MODIFICACIONES
-------------------------------------------------------------------------------------------
AUTOR:		
FECHA:			
CAMBIOS:		

-------------------------------------------------------------------------------------------

*/


defined ( '_JEXEC' ) or die ( 'Restricted access' );
class TOOLBAR_visit{
	function _NEW() {
		JToolBarHelper::addNew();              
		//JToolBarHelper::trash();              
		//JToolBarHelper::cancel();
	}
        function _EDIT(){
           //JToolBarHelper::editList();
        }
        function _TRASH(){
           JToolBarHelper::trash();

        }
	function _DEFAULT(){
		JToolBarHelper::title( JText::_( 'Solicitud de Visitas' ), 'generic.png');
                //JToolBarHelper::makeDefault();
		JToolBarHelper::makeDefault();
		//JToolBarHelper::deleteList();
	}
}
?>

	
