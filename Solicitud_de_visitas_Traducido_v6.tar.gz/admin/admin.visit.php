<?php

/*
-------------------------------------------------------------------------------------------
FICHERO:		admin.visit.php
-------------------------------------------------------------------------------------------
			showVisit( $option)			

FUNCION(ES):	Carga los servidores
LLAMANTE(S):	swith($task)  $task->add
PARAMETROS:	$option -> com_visit

			showVisits( $option )

FUNCION(ES):	Carga todos los servidores
LLAMANTE(S):	swith($task)  $task->default
PARAMETROS:	$option -> com_visit

			saveVisit( $option )

FUNCION(ES):	Guarda los datos de registro en un servidor
LLAMANTE(S):	swith($task)  $task->save
PARAMETROS:	$option -> com_visit

-------------------------------------------------------------------------------------------
CREACIÓN
-------------------------------------------------------------------------------------------
AUTOR:			Javier García San Juan
FECHA:			07/10/2010
-------------------------------------------------------------------------------------------
MODIFICACIONES
-------------------------------------------------------------------------------------------
AUTOR:		Javier García San Juan
FECHA:		11/10/2010
CAMBIOS:	Añadida paginación en el back-end
-------------------------------------------------------------------------------------------
AUTOR:		Javier García San Juan
FECHA:		18/10/2010
CAMBIOS:	Listado Visitas ordenado por fechas
-------------------------------------------------------------------------------------------
AUTOR:
FECHA:
CAMBIOS:

-------------------------------------------------------------------------------------------

*/

require_once("DB.php");


defined ( '_JEXEC' ) or die ( 'Restricted access' );
require_once( JApplicationHelper::getPath( 'admin_html' ) );
JTable::addIncludePath(JPATH_COMPONENT.DS.'tables');

switch($task)
{
	
	case 'edit':
		showVisit($option);
                break;
	case 'add':
		AddServer( $option );
		break;
	case 'default':
		predeterminado ( $option );
		break;
        case 'save':
                saveVisit ( $option );
                break;
        case 'save_new':
                saveVisit2( $option );
                break;
        case 'remove':
                removeServer ( $option);
                break;
	default:
		showVisits( $option );
		break;

}

function removeServer ($option)
{
    	global $mainframe;
	$cid = JRequest::getVar( 'cid',array(),'','array');
	$db =& JFactory::getDBO();
	if(count($cid))
	{
		$cids=implode(',',$cid);
		$query= "DELETE FROM #__servidor WHERE id IN ($cids)";
		$db->setQuery( $query );
		if(!$db->query())
		{
			echo "<script> alert('".$db->getErrorMsg()."');
			window.history.go(-1); </script>\n";
		}
	}
	$mainframe->redirect('index.php?option=' . $option);


    /*    global $mainframe;
        $db =& JFactory::getDBO();
	//$row =& JTable::getInstance('visit','Table');
	$cid = JRequest::getVar('cid',array(0),'','array');
	$id = $cid[0];

        
        $cids = implode( ',', $cid );
        
        $query ="DELETE * FROM #__servidor";

        
        $db->setQuery( $query);
        if($db->getErrorNum()){
		echo $db->stderr();
		return false;
        }
        //echo $query;
	$mainframe->redirect('index.php?option='.$option.'');*/
}

function predeterminado( $option )
{

        global $mainframe;
	//$row =& JTable::getInstance('visit','Table');
	$cid = JRequest::getVar('cid',array(0),'','array');
	$id = $cid[0];

        $db =& JFactory::getDBO();
        $query ="SELECT * FROM #__servidor";
        $db->setQuery( $query);
        if($db->getErrorNum()){
		echo $db->stderr();
		return false;
        }
        $rows = $db->loadObjectList();

        foreach($rows as $rowdb)
        {

                if($rowdb->id == $id)
                {
                    $rowdb->activado = 1;
                    $basedatos = $rowdb->baseDatosTabla;
                }
                //else $rowdb->activado = 0;
                
                $row =& JTable::getInstance('servidor', 'Table');

                if (!$row->bind($rowdb)) {
                    return JError::raiseWarning( 500, $row->getError() );
                }
                if (!$row->store()) {
                JError::raiseError(500, $row->getError() );
                }
        
        }
        foreach($rows as $rowdb)
        {
            if(($rowdb->id != $id) && ($basedatos == $rowdb->baseDatosTabla))
            {
                $rowdb->activado = 0;
            }

                $row =& JTable::getInstance('servidor', 'Table');

                if (!$row->bind($rowdb)) {
                    return JError::raiseWarning( 500, $row->getError() );
                }
                if (!$row->store()) {
                JError::raiseError(500, $row->getError() );
                }
        }


	$mainframe->redirect('index.php?option='.$option.'');
}




function showVisit( $option )
{

        global $mainframe;
	//$row =& JTable::getInstance('visit','Table');
	$cid = JRequest::getVar('cid',array(0),'','array');
	$id = $cid[0];
        

	// Servidores
        $servidores[0] = "venus";
        $servidores[1] = "jupiter";

	HTML_visit::showVisit($servidores, $option, $id);
}


function AddServer( $option )
{

        global $option, $mainframe;
	//$row =& JTable::getInstance('visit','Table');
	$cid = JRequest::getVar('cid',array(0),'','array');
        
	$id = $cid[0];

        //echo $id;
	HTML_visit::AddServer( $option, $id);
}


function saveVisit2( $option )
{
    global $mainframe;
	$servidor =& JTable::getInstance('servidor', 'Table');



	if (!$servidor->bind(JRequest::get('post'))) {
            return JError::raiseWarning( 500, $servidor->getError() );
	}
        else
        {

/*


                // buscamos el teléfono del parque a visitar

		//establecemos la conexion con la BD de parques

		// construimos la consulta

*/
            //HACEMOS UNA PRUEBA
            //define ($servidor->baseDatos,$servidor->nombreServidor."."."bombers.dva.gva.es");
            //$conn_parques=DB::connect("pgsql://".$servidor->usuario.":".$servidor->password."@".constant($servidor->baseDatos)."/maestros");

            //if (DB::isError($conn_parques)){
		//	die($conn_parques->getMessage());
            //}
            // MIRAMOS SI YA ESTA REGISTRADO

            $db =& JFactory::getDBO();
            $query ="SELECT * FROM #__servidor";
            $db->setQuery( $query);
            if($db->getErrorNum()){
		echo $db->stderr();
		return false;
            }
            $rows = $db->loadObjectList();
            $ya_esta = 0;
            if($servidor->descripcion=='Guardar Datos Solicitud')
            {
                $servidor->baseDatos = 'HOSTDB1';
            }
            if($servidor->descripcion=='Listar Parques de Bomberos')
            {
                $servidor->baseDatos = 'HOSTDB2';
            }
            if($servidor->descripcion=='Listar Poblaciones')
            {
                $servidor->baseDatos = 'HOSTDB3';
            }
            foreach($rows as $rowdb)
            {
                if($rowdb->usuario == $servidor->usuario && $rowdb->password == $servidor->password
                    && $rowdb->baseDatos == $servidor->baseDatos && $rowdb->nombreServidor == $servidor->nombreServidor
                        && $rowdb->baseDatosTabla == $servidor->baseDatosTabla && $rowdb->descripcion == $servidor->descripcion)
                {
                    $ya_esta=1;
                    $rowdb->activado = 1;
                }
                else
                {
                    if($rowdb->descripcion == $servidor->descripcion)
                        $rowdb->activado = 0;
                }
                $row =& JTable::getInstance('servidor', 'Table');

                if (!$row->bind($rowdb)) {
                    return JError::raiseWarning( 500, $row->getError() );
                }
                if (!$row->store()) {
                JError::raiseError(500, $row->getError() );
                }

            }

        }
        if($ya_esta)
        {
            $msg = 'Tus datos del servidor han sido activados';
        }
        else{
            $servidor->activado = 1;
            if (!$servidor->store()) {
                JError::raiseError(500, $servidor->getError() );
            }
            $msg = 'Datos Servidor Guardados';
        }

	$task ="";


        $link = 'index.php?option=' . $option;
        $mainframe->redirect($link, $msg);

}

function saveVisit( $option )
{
	global $mainframe;
	$servidor =& JTable::getInstance('servidor', 'Table');


        
	if (!$servidor->bind(JRequest::get('post'))) {
            return JError::raiseWarning( 500, $servidor->getError() );
	}
        else
        {

/*
            

                // buscamos el teléfono del parque a visitar

		//establecemos la conexion con la BD de parques
		
		// construimos la consulta

*/
            //HACEMOS UNA PRUEBA
            define ($servidor->baseDatos,$servidor->nombreServidor."."."bombers.dva.gva.es");
            $conn_parques=DB::connect("pgsql://".$servidor->usuario.":".$servidor->password."@".constant($servidor->baseDatos)."/maestros");
            
            if (DB::isError($conn_parques)){
			die($conn_parques->getMessage());
            }
            // MIRAMOS SI YA ESTA REGISTRADO

            $db =& JFactory::getDBO();
            $query ="SELECT * FROM #__servidor";
            $db->setQuery( $query);
            if($db->getErrorNum()){
		echo $db->stderr();
		return false;
            }
            $rows = $db->loadObjectList();
            $ya_esta = 0;
            foreach($rows as $rowdb)
            {
                if($rowdb->usuario == $servidor->usuario && $rowdb->password == $servidor->password
                    && $rowdb->baseDatos == $servidor->baseDatos && $rowdb->nombreServidor == $servidor->nombreServidor
                        && $rowdb->baseDatosTabla == $servidor->baseDatosTabla)
                {
                    $ya_esta=1;
                    $rowdb->activado = 1;
                }
                else 
                    if($rowdb->descripcion == $servidor->descripcion)
                {
                    $rowdb->activado = 0;
                }
                $row =& JTable::getInstance('servidor', 'Table');
                
                if (!$row->bind($rowdb)) {
                    return JError::raiseWarning( 500, $row->getError() );
                }
                if (!$row->store()) {
                JError::raiseError(500, $row->getError() );
                }

            }
        }
        if($ya_esta)
        {
            $msg = 'Tus datos del servidor han sido activados';
        }
        else{
            $servidor->activado = 1;
            if (!$servidor->store()) {
                JError::raiseError(500, $servidor->getError() );
            }
            $msg = 'Datos Servidor Guardados';
        }
	
	$task ="";

        
        $link = 'index.php?option=' . $option;
        $mainframe->redirect($link, $msg);

	
	
}

function showVisits ( $option )
{
        global $option, $mainframe;
        $limit = JRequest::getVar('limit', $mainframe->getCfg('list_limit'));
        $limitstart = JRequest::getVar('limitstart',0);
	$db =& JFactory::getDBO();
	$query = "SELECT count(*) FROM #__visit";
	$db->setQuery( $query );
        $total = $db->loadResult();


        

        $query = "SELECT * FROM #__visit ORDER by fecha ASC";
	$db->setQuery( $query, $limitstart, $limit );
	$rows = $db->loadObjectList();
	//$rows->nameCole;
	if($db->getErrorNum()){
		echo $db->stderr();
		return false;
	}
        jimport('joomla.html.pagination');
        $pageNav = new JPagination( $total, $limitstart, $limit);
	HTML_visit::showVisits( $option, $rows, $pageNav);
}

function removeVisit ( $option)
{
	global $mainframe;
	$cid = JRequest::getVar( 'cid',array(),'','array');
	$db =& JFactory::getDBO();
	if(count($cid))
	{
		$cids=implode(',',$cid);
		$query= "DELETE FROM #__visit WHERE id IN ($cids)";
		$db->setQuery( $query );
		if(!$db->query())
		{
			echo "<script> alert('".$db->getErrorMsg()."');
			window.history.go(-1); </script>\n";
		}	
	}
	$mainframe->redirect('index.php?option=' . $option);		
}

?>


