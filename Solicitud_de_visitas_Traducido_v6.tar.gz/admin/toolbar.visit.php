<?php


/*
-------------------------------------------------------------------------------------------
FICHERO:		toolbar.visit.php
-------------------------------------------------------------------------------------------
			TOOLBAR	

FUNCION(ES):	Botones para el componente visit
LLAMANTE(S):
PARAMETROS:	


-------------------------------------------------------------------------------------------
CREACIÓN
-------------------------------------------------------------------------------------------
AUTOR:			Javier García San Juan
FECHA:			07/10/2010
-------------------------------------------------------------------------------------------
MODIFICACIONES
-------------------------------------------------------------------------------------------
AUTOR:		
FECHA:			
CAMBIOS:		

-------------------------------------------------------------------------------------------

*/


defined ( '_JEXEC' ) or die ( 'Restricted access' );
require_once( JApplicationHelper::getPath( 'toolbar_html' ) );
switch($task)
{

        case 'new':
                break;
	case 'edit':
		
	case 'add':
		break;

	default:
                TOOLBAR_visit::_NEW();
                TOOLBAR_visit::_EDIT();
                TOOLBAR_visit::_TRASH();                
		TOOLBAR_visit::_DEFAULT();
                break;
}
?>
