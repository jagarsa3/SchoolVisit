<?php


/*
-------------------------------------------------------------------------------------------
FICHERO:		visit.html.php
-------------------------------------------------------------------------------------------
			builHeader()

FUNCION(ES):	Incluye el joomla.javascript.js, necesario para que aparezca el calendario
		en el front-end de Joomla.
LLAMANTE(S):	visit.html.php en la apartado fecha de la función editvisit
PARAMETROS:	

			editVisit( $row, $lists, $option)

FUNCION(ES):	Display formulario para editarlo por el usuario (front-end)
LLAMANTE(S):	visit.php en la función editVisit( $option )
PARAMETROS:	$row->datos visita,$lists->opciones de (ciudad y parque),$option->com_visit

			showVisit( $row, $lists, $option)

FUNCION(ES):	Imprime un formulario para posible resguardo (front-end)
LLAMANTE(S):	visit.php en la función saveVisit( $option )
PARAMETROS:	$row->datos visita,$lists->opciones de (ciudad y parque),$option->com_visit
-------------------------------------------------------------------------------------------
CREACIÓN
-------------------------------------------------------------------------------------------
AUTOR:			Javier García San Juan
FECHA:			07/10/2010
-------------------------------------------------------------------------------------------
MODIFICACIONES
-------------------------------------------------------------------------------------------
AUTOR:		Javier García San Juan
FECHA:		11/10/2010
CAMBIOS:	Añadido contador de Solicitudes de visitas

-------------------------------------------------------------------------------------------
AUTOR:          Javier García San Juan
FECHA:          13/10/2010
CAMBIOS:        Fechas mas vistosas con JHTML::Date(fecha)

-------------------------------------------------------------------------------------------
AUTOR:          Javier García San Juan
FECHA:          13/10/2010 - 28/10/2010
CAMBIOS:        Validacion con Javascript, imprimir resguardo..

-------------------------------------------------------------------------------------------
AUTOR:
FECHA:
CAMBIOS:

-------------------------------------------------------------------------------------------


*/

// BASE DATOS JUPITER

// require_once("DB.php");
// define ("HOSTDB1","jupiter.bombers.dva.gva.es");
// define ("HOSTDB1","venus.bombers.dva.gva.es");

require_once("DB.php");
//$db =& JFactory::getDBO();
//$query = "SELECT * FROM #__servidor WHERE activado='1'";
//$db->setQuery( $query);
//$rows = $db->loadRow();
?>

<?php

//echo $rows->nombreServidor;

//define ($rows['baseDatos'],$rows['nombreServidor']."bombers.dva.gva.es");



defined( '_JEXEC' ) or die ( 'Restricted access' ) ;
require_once(JPATH_COMPONENT.DS.'helper.php');
//JTable::addIncludePath(JPATH_ADMINISTRATOR.DS.'components'.DS.$option.DS.'tables');



class HTML_visit
{
         function restarFechashtml($dFecIni, $dFecFin)
         {
                $dFecIni = str_replace("-","",$dFecIni);
                $dFecIni = str_replace("/","",$dFecIni);
                $dFecFin = str_replace("-","",$dFecFin);
                $dFecFin = str_replace("/","",$dFecFin);

                ereg( "([0-9]{1,2})([0-9]{1,2})([0-9]{2,4})", $dFecIni, $aFecIni);
                ereg( "([0-9]{1,2})([0-9]{1,2})([0-9]{2,4})", $dFecFin, $aFecFin);

                $date1 = mktime(0,0,0,$aFecIni[2], $aFecIni[1], $aFecIni[3]);
                $date2 = mktime(0,0,0,$aFecFin[2], $aFecFin[1], $aFecFin[3]);

                return round(($date2 - $date1) / (60 * 60 * 24));
        }

	function editVisit( $row, $lists, $option )
	{
		$editor =& JFactory::getEditor();
		JHTML::_('behavior.calendar');
                
                // CARGAMOS EL SERVIDOR DESDE JOOMLA
                $db =& JFactory::getDBO();


                // INSTRUCCIONES RELLENAR FORMULARIO

		?>


<hml>
<head>
<link rel="stylesheet" href="/plugins/system/jceutilities/css/jceutilities-217.css" type="text/css" />
<link rel="stylesheet" href="/plugins/system/jceutilities/themes/standard/css/style.css" type="text/css" />
</head
    <body>

        	<script type="text/javascript">


	function validarEntero(valor)
        {
		//intento convertir a entero.
	    //si era un entero no le afecta, si no lo era lo intenta convertir a un numero decimal
	    valor = parseInt(valor,10);
	    //Compruebo si es un valor numérico
	    if (isNaN(valor)) {
		    return "";
	    }
		else{
	        return valor;
	    }
	}



      function validarDiasMes(mes, dia)
        {
            diaok=validarEntero(dia);
            mesok=validarEntero(mes);
            if(mesok==2){
                if(diaok<=29){
                    restoanyook=anyook%4;
                    if(restoanyook > 0 && diaok>28) return false;
                    else return true;
                }
                else return false;
            }
            else if((mesok==4 || mesok==6 || mesok==9 || mesok==11) && diaok>30)
                return false;           
            else
                return true;
        }

	function validarFecha(dia,mes,anyo)
        {

	   	diaok=validarEntero(dia);
		mesok=validarEntero(mes);
		anyook=validarEntero(anyo);

		if((diaok!="" && diaok>0 && diaok<=31) && (mesok!="" && mesok>0 && mesok<=12) && (anyook!="" && anyook>=2000)){
			//comprobar febrero:
			if(mesok==2){
				if(diaok<=29){
					restoanyook=anyook%4;
					if(restoanyook > 0 && diaok>28)	return false;
					else return true;
				}
				else return false;
			}
			else if((mesok==4 || mesok==6 || mesok==9 || mesok==11) && diaok>30)
					return false;
			else return true;
		}
		 return false;
	}


        function DiferenciaFechas (dia,mes,anyo,diam,mesm,anyom) {

          //Obtiene objetos Date
          var miFecha1 = new Date( anyo, mes-1, dia )
          var miFecha2 = new Date( anyom, mesm-1, diam )

          //Resta fechas y redondea
          var diferencia = miFecha1.getTime() - miFecha2.getTime()
          var dias = Math.floor(diferencia / (1000 * 60 * 60 * 24))
          
          return dias
         }

         function restarFechasperiodos(diaini,mesini, diafin, mesfin)
        {
            diafunc = diafin - diaini;
            mesfunc = mesfin - mesini;
            mesfunc = mesfunc * 31;
            diafunc = diafunc + mesfunc;

            return diafunc;
        }

	function comprobar_datos(f){
		//nombre_centro
		if (document.forms.adminForm.nameCole.value==''){
                        var error = "<?php echo JText::_( 'Error1'); ?>";
			alert(error);
			return false;
		}
		//dir_centro
		if (document.forms.adminForm.dir.value==''){
                        var error = "<?php echo JText::_( 'Error19'); ?>";
			alert(error);
			return false;
		}
		//city_centro
		if (document.forms.adminForm.city.value==''){
                        var error = "<?php echo JText::_( 'Error2'); ?>";
			alert(error);
			return false;
		}
                //city_centro
		if (document.forms.adminForm.city.value=="<?php echo JText::_( 'Seleccionaciudad'); ?>"){
                        var error = "<?php echo JText::_( 'Error2'); ?>";
			alert(error);
			return false;
		}
		//nombre_responsable
		if (document.forms.adminForm.nameProfe.value==''){
                        var error = "<?php echo JText::_( 'Error3'); ?>";
			alert(error);
			return false;
		}
		//telefono_responsable y movil_responsable
		if (isNaN(document.forms.adminForm.telf.value) || document.forms.adminForm.telf.value==''){
                        document.forms.adminForm.telf.value='';
                        var error = "<?php echo JText::_( 'Error4'); ?>";
			alert(error);
			return false;
		}


                if(isNaN(document.forms.adminForm.movil.value) && (!document.forms.adminForm.movil.value=='')){
                        document.forms.adminForm.movil.value='';
                        var error = "<?php echo JText::_( 'Error5'); ?>";
			alert(error);
			return false;
                }

                // VALIDACION TELEFONO FIJO
                valor = document.forms.adminForm.telf.value;
                if( !(/^\d{9}$/.test(valor))&& !(/^\d{2,3}\d{9}$/.test(valor)) ) {
                    document.forms.adminForm.telf.value='';
                    var error = "<?php echo JText::_( 'Error6'); ?>";
                    alert(error);
                    return false;

                }
                
                // VALIDACION TELEFONO MOVIL
                valor = document.forms.adminForm.movil.value;
                if(document.forms.adminForm.movil.value!=''){
                    if( !(/^\d{9}$/.test(valor))&& !(/^\d{2,3}\d{9}$/.test(valor)) ) {
                        document.forms.adminForm.movil.value='';
                        var error = "<?php echo JText::_( 'Error7'); ?>";
                        alert(error);
                        return false;
                    }
                }
                
                // VALIDAR MAIL
                // http://lineadecodigo.com/javascript/validar-el-email-con-javascript/
                valor = document.forms.adminForm.email.value;
                pos = -1;
                pos = valor.indexOf("@");
                dot = valor.lastIndexOf(".");
                if(document.forms.adminForm.email.value!=''){
                    if(pos == -1 || pos > dot)
                    {
                        document.forms.adminForm.email.value='';
                        var error = "<?php echo JText::_( 'Error8'); ?>";
                        alert(error);
                        return false;
                    }
                }

		//comprobacion que los 2 num_alumnos no esta en blanco
		if ((document.forms.adminForm.numInf.value=='0' || document.forms.adminForm.numInf.value=='') && (document.forms.adminForm.numPrim.value=='0' || document.forms.adminForm.numPrim.value=='')){
                        document.forms.adminForm.numInf.value='';
                        document.forms.adminForm.numPrim.value='';
                        var error = "<?php echo JText::_( 'Error9'); ?>";
                        alert(error);
                        return false;
		}
                //comprobacion solo debe haber un tipo de alumnos: primaria o infantil
                if ((document.forms.adminForm.numInf.value!='' && document.forms.adminForm.numInf.value!='0')  && (document.forms.adminForm.numPrim.value!='' && document.forms.adminForm.numPrim.value!='0')){ç
                    document.forms.adminForm.numInf.value='';
                    document.forms.adminForm.numPrim.value='';
                    var error = "<?php echo JText::_( 'Error10'); ?>";
                    alert(error);
                    return false;
	  	}

		//comprobacion que alguno de los 2 num_alumnos no sea numerico
		if (isNaN(document.forms.adminForm.numInf.value) || isNaN(document.forms.adminForm.numPrim.value)){
                        document.forms.adminForm.numInf.value='';
                        document.forms.adminForm.numPrim.value='';
                    	var error = "<?php echo JText::_( 'Error11'); ?>";
                    	alert(error);
                    	return false;
		}

		//comprobacion no puede haber mas de 60 alumnos por visita
	    if (document.forms.adminForm.numInf.value>60 || document.forms.adminForm.numPrim.value>60){
                document.forms.adminForm.numInf.value='';
                document.forms.adminForm.numPrim.value='';
		var error = "<?php echo JText::_( 'Error12'); ?>";
                alert(error);
                return false;

	  	}
		//num_acompanyantes
		if (document.forms.adminForm.numAcomp.value=='' || isNaN(document.forms.adminForm.numAcomp.value)|| document.forms.adminForm.numAcomp.value=='0'){
                        document.forms.adminForm.numAcomp.value='';
			var error = "<?php echo JText::_( 'Error13'); ?>";
                	alert(error);
                	return false;

	  	}
		//Hacer la comprobacion de validarFecha en fecha_visita solo si hay algun campo de la fecha que no este en blanco
                dia = document.forms.adminForm.fecha.value.substring(6,8);
                mes = document.forms.adminForm.fecha.value.substring(3,5);
                anyo = document.forms.adminForm.fecha.value.substring(0,2);

                temp = "2"+"0";
                anyo = temp+anyo;
                fecha_correcta=dia+"/"+mes+"/"+anyo;
                if (document.forms.adminForm.fecha.value==''){
                           var error = "<?php echo JText::_( 'Error14'); ?>";
                           alert(error);
                	   return false;
                }
		if (document.forms.adminForm.fecha.value!=''){
			if(!validarFecha(dia,mes,anyo)){
                                document.forms.adminForm.fecha.value='';
				var error = "<?php echo JText::_( 'Error14'); ?>";
                		alert(error);
                		return false;

	  		}
		}
		//comprabamos que observaciones_fecha no este en blanco ya que fecha_visita si lo esta
		if (document.forms.adminForm.fecha.value=='' && document.forms.adminForm.observaciones.value==''){
				var error = "<?php echo JText::_( 'Error15'); ?>";
                		alert(error);
                		return false;

	  	}



                fechaActual = new Date();
                diahoy = fechaActual.getDate();
                meshoy = fechaActual.getMonth() +1;
                anyohoy = fechaActual.getFullYear();
                if (diahoy <10) dia = "0" + dia;
                if (meshoy <10) mes = "0" + mes;


                // POSTERIOR A LA FECHA ACTUAL
                if (document.forms.adminForm.fecha.value!=''){
                    if (DiferenciaFechas(dia,mes,anyo,diahoy,meshoy,anyohoy)<0){
                                document.forms.adminForm.fecha.value='';
				var error = "<?php echo JText::_( 'Error20'); ?>";
                		alert(error);
                		return false;
                    }


                }

                // 7 DIAS DE ANTELACION
                if (document.forms.adminForm.fecha.value!=''){
                    if (DiferenciaFechas(dia,mes,anyo,diahoy,meshoy,anyohoy)<7){
                                document.forms.adminForm.fecha.value='';
				var error = "<?php echo JText::_( 'Error16'); ?>";
                		alert(error);
                		return false;
                    }


                }



                // DIA MIERCOLERS
                var miFecha1 = new Date( anyo, mes-1, dia );
                dialetra = miFecha1.getDay();
                if (document.forms.adminForm.fecha.value!=''){
                    if(dialetra!=3)
                    {
                        document.forms.adminForm.fecha.value='';
			var error = "<?php echo JText::_( 'Error17'); ?>";
                	alert(error);
                	return false;
                    }
                }


                // 1 OCTUBRE
                diaoctubre = "0"+"1";
                mesoctubre = "1"+"0";


                // 31 de Mayo de 2011
                diamayo = "3"+"1";
                mesmayo = "0"+"5";

                // PERIODO DE FECHAS CORRECTO
                if (document.forms.adminForm.fecha.value!=''){
                    if((restarFechasperiodos(dia,mes,diamayo,mesmayo)<0) && (restarFechasperiodos(diaoctubre,mesoctubre,dia,mes)<0) ) {
                        document.forms.adminForm.fecha.value='';
			var error = "<?php echo JText::_( 'Error18'); ?>";
                	alert(error);
                	return false;
                    }
                }

                // VALIDAR FECHA
                valor = document.forms.adminForm.fecha.value;
                if (document.forms.adminForm.fecha.value!=''){
                    if( !(/^\d{2}\-\d{2}\-\d{2}$/.test(valor)) ) {
                        document.forms.adminForm.fecha.value='';
                        var error = "<?php echo JText::_( 'Error14'); ?>";
                        alert(error);
                        return false;
                    }

                }

                //Parque
		if (document.forms.adminForm.parque.value=="<?php echo JText::_( 'Seleccionaparque'); ?>"){
                        var error = "<?php echo JText::_( 'Error21'); ?>";
			alert(error);
			return false;
		}
                
		//Si no hay nada escrito en alguno de los 2 numero de alumnos, su valor es 0
		if (document.forms.adminForm.numInf.value==''){
			document.forms.adminForm.numInf.value=0;
		}
		if (document.forms.adminForm.numPrim.value==''){
			document.forms.adminForm.numPrim.value=0;
		}
		return true;
	}
	function guardar_datos(f){
		if(comprobar_datos(f)){
			f.submit();
		}
	}

	</script>
        <?php

        ?>


                <h3><?php echo JText::_( 'Cumplimentar'); ?></h3>
                <table  >
                    <tr><td>
                    <img src="images/stories/visitaescolar.jpg" align="right"  alt="Imagen para solicitud visitas colegios" >
                        </td>
                    <td>
		<ul ><font size="1">
		<li><?php echo JText::_( 'Autorizan'); ?></li>
		<li><?php echo JText::_( 'Asimismo'); ?></li>
		<li><?php echo JText::_( 'Visitas'); ?></li>
		<li><?php echo JText::_( 'Duracion'); ?></li>
		<li><?php echo JText::_( 'Homogeneos'); ?></li>
		<li><?php echo JText::_( 'Maximo'); ?></li>
		<li><?php echo JText::_( 'Apartado'); ?>

		<ul type="square">
		<li><?php echo JText::_( 'Alumnos'); ?></li>
		<li><?php echo JText::_( 'Alternativas'); ?></li>
		<li><?php echo JText::_( 'Otros'); ?></li>
		<li><?php echo JText::_( 'Otras'); ?></li>
		<li><?php echo JText::_( 'Cualquier'); ?></li>
		</ul></li>
		<li><?php echo JText::_( 'Jefeparque'); ?></li>
		<li><?php echo JText::_( 'Asterisco'); ?></li></font>
		</ul>
                        </td></tr></table><br/>

                
                <!--Diseñado por Javier García San Juan-->



		


		<form action="" method="post"
				name="adminForm" id="adminForm">
			<fieldset class="adminform">
				<legend><h3><?php echo JText::_( 'Solvisitas' )?></h3></legend>
				<table class="admintable">
				<tr>
					<td width="250" align="right" class="key">
						<?php echo JText::_( 'Nombre'); ?>:(*)
					</td>
					<td>
						<input class="text_area" type="text" name="nameCole"
							id="nameCole" size="45" maxlength="250"
							value="<?php echo $row->nameCole;?>" /> 
						
					</td>
				</tr>
				<tr>
					<td width="100" align="right" class="key">
						<?php echo JText::_( 'Direccion'); ?>:(*)
					</td>
					<td>
						<input class="text_area" type="text" name="dir"
							id="dir" size="45" maxlength="250"
							value="<?php echo $row->dir;?>" />
						
					</td>
				</tr>
				<tr>
					<td width="100" align="right" class="key">
						<?php echo JText::_( 'Poblacion'); ?>:(*)
					</td>
					<td>
						<?php echo $lists['city'];?>
						
					</td>
				</tr>
				<tr>
					<td width="100" align="right" class="key">
						<?php echo JText::_( 'Nombreresp'); ?>:(*)
					</td>
					<td>
						<input class="text_area" type="text" name="nameProfe"
							id="nameProfe" size="45" maxlength="250"
							value="<?php echo $row->nameProfe;?>" />
						
					</td>
				</tr>
				<tr>
					<td width="100" align="right" class="key">
						<?php echo JText::_( 'Telefono'); ?>:(*)
					</td>
					<td>
						<input class="text_area" type="text" name="telf" id="telf" size="15" maxlength="15" 								value="<?php echo $row->telf;?>" />
						
					</td>
				</tr>
				<tr>
					<td width="100" align="right" class="key">
						<?php echo JText::_( 'Movil'); ?>:
					</td>
					<td>
						<input class="text_area" type="text" name="movil" id="movil" size="15" maxlength="15" 								value="<?php echo $row->movil;?>" />
					</td>
				</tr>
				<tr>
					<td width="100" align="right" class="key">
						<?php echo JText::_( 'Email'); ?>:
					</td>
					<td>
						<input class="text_area" type="text" name="email" id="email" size="45" maxlength="50" 								value="<?php echo $row->email;?>" />
					</td>
				</tr>
				<tr>
					<td width="100" align="right" class="key">
						<?php echo JText::_( 'Numinf'); ?>:(*)
					</td>
					<td>
						<input class="text_area" type="text" name="numInf" id="numInf" size="5" maxlength="3" 								value="<?php echo $row->numInf;?>" />
						
					</td>
				</tr>
				<tr>
					<td width="100" align="right" class="key">
						<?php echo JText::_( 'Numprim'); ?>:(*)
					</td>
					<td>
						<input class="text_area" type="text" name="numPrim" id="numPrim" size="5" maxlength="3" 
							value="<?php echo $row->numPrim;?>" />
						
					</td>
				</tr>
				<tr>
					<td width="100" align="right" class="key">
						<?php echo JText::_( 'Numacomp'); ?>:(*)
					</td>
					<td>
						<input class="text_area" type="text" name="numAcomp" id="numAcomp" size="5" maxlength="3" 
								value="<?php echo $row->numAcomp;?>" />
						
					</td>
				</tr>
				<tr>
					<td width="100" align="right" class="key">
						<?php echo JText::_( 'Parque'); ?>:(*)
					</td>
					<td>
						<?php echo $lists['parque'];?>
						
					</td>
				</tr>
				<tr>
					<td width="100" align="right" class="key">
						<?php echo JText::_( 'Fecha'); ?>:(*)
					<?php buildHeader() ?>
					</td>
					<td>
						<input class="inputbox" type="text" name="fecha" id="fecha" size="10" maxlength="10" 
							value="<?php echo $row->fecha;?>" />
						<input type="reset" class="button" value="..." 
							onclick="return showCalendar('fecha','%y-%m-%d');"/>
					</td>
				</tr>
				<tr>
					<td width="100" align="right" class="key">				
						<?php echo JText::_( 'Observaciones'); ?>:
					</td>
					<td>
						<textarea class="text_area" type="text" name="observaciones" id="observaciones" style="width:325px"
                                                           value="<?php echo $row->observaciones;?>"></textarea>
					</td>
				</tr>			
				</table>
			</fieldset>
			<input type="hidden" name="id" value="<?php echo $row->id; ?>" />
			<input type="hidden" name="option" value="<?php echo $option; ?>" />
			<input type="hidden" name="task" value="save" />
                        
                        <input type="button" class="button" id="guardar "onClick="guardar_datos(this.form)" value="Enviar">

			<input type="reset" class="button" id="clean" value="<?php echo JText::_( 'Limpiar'); ?>" />
		</form>
    </body>
</html>
		

		<?php
	}

          
	function buildHeader()
	{
	   $user = JFactory::getUser();
	   $document =& JFactory::getDocument();

	   /** zu includierende CSS-Dateien */
	   $document->addStyleSheet( "components/com_joowein/assets/css/joowein.css" );
	   
	   /** zu includierende JS-Dateien */
	   if(!$user->id || $user->id == 0) {
		  $document->addScript( "includes/js/joomla.javascript.js" );
	   }
	   $document->addScript( "components/com_joowein/assets/js/joowein.js" );
	}



	function showVisit( $row, $lists, $option, $num_visita )
	{

		$editor =& JFactory::getEditor();
		?>
		<p><font size="3"><?php echo JText::_( 'Guardada'); ?><?php echo $num_visita?></font></p>
		<td colspan="2"><h3><?php echo JText::_( 'Datosolicitud'); ?></h3></td>
		<p class="contentheading"><strong><h2><u><?php $nameCole = stripslashes($row->nameCole); echo $nameCole; ?></u></h2></strong></p>
		<p class="createdate"><?php $fecha_actual = date(d."-".m."-".Y);
                echo JHTML::Date ($fecha_actual); ?></p>
                <p><font size="3"><strong><?php echo JText::_( 'Direccion'); ?>: </strong><?php $dir = stripslashes($row->dir); echo $dir; ?></font></p>
		<p><font size="3"><strong><?php echo JText::_( 'Poblacion'); ?>: </strong><?php $city = stripslashes($row->city); echo $city; ?></font></p>
		<p><font size="3"><strong><?php echo JText::_( 'Nombreresp'); ?>: </strong><?php $nameProfe = stripslashes($row->nameProfe); echo $nameProfe; ?></font></p>
		<p><font size="3"><strong><?php echo JText::_( 'Telefono'); ?>: </strong><?php echo $row->telf; ?></font></p>
		<p><font size="3"><strong><?php echo JText::_( 'Movil'); ?>: </strong><?php echo $row->movil;  ?></font></p>
		<p><font size="3"><strong><?php echo JText::_( 'Email'); ?>: </strong><?php $email = stripslashes($row->email); echo $email;  ?></font></p>
		<p><font size="3"><strong><?php echo JText::_( 'Numinf'); ?>: </strong><?php echo $row->numInf;  ?></font></p>
		<p><font size="3"><strong><?php echo JText::_( 'Numprim'); ?>: </strong><?php echo $row->numPrim;  ?></font></p>
		<p><font size="3"><strong><?php echo JText::_( 'Numacomp'); ?>: </strong><?php echo $row->numAcomp;  ?></font></p>
		<p><font size="3"><strong><?php echo JText::_( 'Parque'); ?>: </strong><?php $parque = stripslashes($row->parque);echo $parque;  ?></font></p>
		<p><font size="3"><strong><?php echo JText::_( 'Fecha'); ?>: </strong><?php
                
                if($row->fecha==''){
                    
                }
                else{
                    $dia = substr($row->fecha,6 ,2 );
                    $mes =   substr($row->fecha,3 ,2 );
                    $ano = substr($row->fecha,0 ,2 );
                    $ano = "2"."0".$ano;
                    $fecha_visita = date(d."-".m."-".Y,mktime(0, 0, 0, $mes, $dia, $ano));
                    echo JHTML::Date ($fecha_visita);
                }
                

                // CARGAMOS EL SERVIDOR DESDE JOOMLA
                $db =& JFactory::getDBO();
                ;

                //echo $rowserver['4']." ".$rowserver['1']."."."bombers.dva.gva.es";
                

                // buscamos el teléfono del parque a visitar

		//establecemos la conexion con la BD de parques
                $dbmaestros =& JFactory::getDBO();
                $querymaestros = "SELECT * FROM #__servidor WHERE activado='1' and descripcion='Listar Parques de Bomberos'";
                $dbmaestros->setQuery( $querymaestros);
                $rowservermaestros = $dbmaestros->loadRow();
                define ($rowservermaestros['4'],$rowservermaestros['1']."."."bombers.dva.gva.es");

		$conn_parques=DB::connect("pgsql://".$rowservermaestros['2'].":".$rowservermaestros['3']."@".constant($rowservermaestros['4'])."/".$rowservermaestros['6']."");
		// construimos la consulta
		$sql_parques = "select telefono from parques where poblacion ='".$row->parque."'";
		$res_parques = $conn_parques->getOne($sql_parques);
		if (DB::isError($res_parques)){
			die($res_parques->getMessage());
		}
                ?></font></p>
		<p><font size="3"><strong><?php echo JText::_( 'Observaciones'); ?>: </strong><?php $observaciones = stripslashes($row->observaciones);echo $observaciones;  ?></font></p>
		<p> <?php echo JText::_( 'Informacion'); ?> <?=$parque?> <?php echo JText::_( 'TELEFONOJEFE')." ";?> <?=$res_parques;?> <?php echo JText::_( 'Jefe'); ?></p>
		<p> <b> <?php echo JText::_( 'Imprimir'); ?></b><p>
                <?php // Configurar los parámetros del objeto
                //$params = & new mosParameters( '' );
                $params = JComponentHelper::getParams('com_foobar');
                $params->def( 'print', true );
                $params->def( 'popup', true );
                $params->def( 'icons', true );

                // Configurar la url que se abrirá al clickear sobre el icono de la impresora
                $url = $mosConfig_live_site . '/index2.php?option=com_content&task=view&id=' .
                $row->id .'&Itemid='. $Itemid;

                // Insertar el icono impresora con la opciones previamente configuradas..
                mosHTML::PrintIcon( $row, $params , false, $url )  ?>
		<p> <?php echo JText::_( 'Pulse'); ?> <a href="http://www.bombers.dva.gva.es"> <?php echo JText::_( 'Aqui'); ?></a> <?php echo JText::_( 'Principal'); ?> </p>
		<?php $link = JRoute::_('index.php?option=' . $option); ?>
		<a href="<?php echo $link; ?>">&lt;<?php echo JText::_( 'Listado'); ?></a>

		<?php
	}

}


	?>

