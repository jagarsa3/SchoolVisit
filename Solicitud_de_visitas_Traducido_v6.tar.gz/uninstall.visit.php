<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
defined( '_JEXEC' ) or die ( 'Restricted access' ) ;

function com_uninstall()
{
    ?>
    <div class="header">La solicitud de visitas ha sido
                        desinstalada de su sistema.</div>
    <p>
    Gracias por haber confiado en nosotros!. Esperamos
    haberles sido de gran ayuda.
    </p>
    <?php
}

?>
