<?php 

/*
-------------------------------------------------------------------------------------------
FICHERO:		helper.php
-------------------------------------------------------------------------------------------
FUNCION(ES):	Incluye el joomla.javascript.js, necesario para que aparezca el calendario
		en el front-end de Joomla.
LLAMANTE(S):	visit.html.php en la apartado fecha de la función editvisit
PARAMETROS:	
-------------------------------------------------------------------------------------------
CREACIÓN
-------------------------------------------------------------------------------------------
AUTOR:			Javier García San Juan
FECHA:			07/10/2010
-------------------------------------------------------------------------------------------
MODIFICACIONES
-------------------------------------------------------------------------------------------
AUTOR:		
FECHA:			
CAMBIOS:		

-------------------------------------------------------------------------------------------

*/



function buildHeader()
{
   $user = JFactory::getUser();
   $document =& JFactory::getDocument();

   /** zu includierende CSS-Dateien */
   $document->addStyleSheet( "components/com_joowein/assets/css/joowein.css" );
   
   /** zu includierende JS-Dateien */
   if(!$user->id || $user->id == 0) {
      $document->addScript( "includes/js/joomla.javascript.js" );
   }
   $document->addScript( "components/com_joowein/assets/js/joowein.js" );
}
?>
