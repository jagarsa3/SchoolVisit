<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
defined( '_JEXEC' ) or die ( 'Restricted access' ) ;

function com_install()
{
    ?>
    <div class="header">Enorabuena, la solicitud de Visitas de
                        Colegios esta lista para funcionar</div>
    <p>
    Gracias por instalar el componente solicitud de visitas de colegios
    para parques de bomberos, espero que les sirva de gran ayuda.
    </p>
    <?php
}

?>
