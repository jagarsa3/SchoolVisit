<?php
defined ( '_JEXEC' ) or die ( 'Restricted access' );
class TableVisit extends JTable
{
	var $id = null;
	var $nameCole = null;
	var $dir = null;
	var $city = null;
	var $nameProfe = null;
	var $telf = null;
	var $movil = null;
	var $email = null;
	var $numInf = null;
	var $numPrim = null;
	var $numAcomp = null;
	var $parque = null;
	var $fecha = null;
	var $observaciones = null;
	function __construct(&$db)
	{
		parent::__construct ( '#__visit', 'id', $db);
	}
}
?>
